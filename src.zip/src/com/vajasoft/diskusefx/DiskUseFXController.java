package com.vajasoft.diskusefx;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.stage.DirectoryChooser;
import javafx.stage.DirectoryChooserBuilder;

/**
 *
 * @author Pertti Uppala
 */
public class DiskUseFXController implements Initializable {
    private static NodeComparator sComparator = new NodeComparator(false);
    private static final int X_LARGEST = 10;
    private static final int SIZE_UNIT = 1024 * 1024;
    private static final String SIZE_UNIT_LABEL = "Mb";
    private AppContext ctx;
    private DirectoryChooser dirChooser;
    private File currentRoot;
    private @FXML
    MenuItem mnuParent;
    private @FXML
    MenuItem mnuRefresh;
    private @FXML
    Button cmdParent;
    private @FXML
    Button cmdRefresh;
    private @FXML
    TreeView dirTree;
    private @FXML
    BarChart topTen;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        DirectoryChooserBuilder dcb = DirectoryChooserBuilder.create();
        dirChooser = dcb.build();
        dirTree.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<FileNode>() {
            @Override
            public void changed(ObservableValue<? extends FileNode> ov, FileNode oldVal, FileNode newVal) {
                if (newVal != null) {
                    setChart(newVal);
                }
            }
        });
        topTen.setAnimated(false);
        setCommands();
    }

    void setAppContext(AppContext ctx) {
        this.ctx = ctx;
    }

    @FXML
    private void onExit(ActionEvent ev) {
        Platform.exit();
    }

    @FXML
    private void onOpen(ActionEvent ev) {
        File choice = dirChooser.showDialog(ctx.getMainWindow());
        if (choice != null) {
            setCurrent(choice);
        }
    }

    @FXML
    private void onParent(ActionEvent ev) {
        File f = currentRoot.getParentFile();
        if (f != null) {
            setCurrent(f);
        }
    }

    @FXML
    private void onRefresh(ActionEvent ev) {
        setCurrent(currentRoot);
    }

    public void setCurrent(File f) {
        try {
            currentRoot = f.getCanonicalFile();
            TreeBuilderTask builder = new TreeBuilderTask(currentRoot.toPath(), new WorkerStateEventHandler());
            Thread th = new Thread(builder);
            th.setDaemon(true);
            th.start();
            setCommands();
        } catch (IOException ex) {
            Logger.getLogger(DiskUseFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setChart(FileNode node) {
        int count = node.getChildren().size();
        FileNode[] nodes = new FileNode[count];
        for (int i = 0; i < count; i++) {
            nodes[i] = (FileNode) node.getChildren().get(i);
        }
        java.util.Arrays.sort(nodes, sComparator);
        count = Math.min(count, X_LARGEST);
        ObservableList<BarChart.Data> barChartData = FXCollections.observableArrayList();
        for (int i = 0; i < count; i++) {
            barChartData.add(new BarChart.Data(nodes[i].getName(), nodes[i].getSize() / SIZE_UNIT));
        }

        topTen.setTitle(node.getPathName() + " (" + (node.getSize() / SIZE_UNIT) + " " + SIZE_UNIT_LABEL + ")");
        topTen.getYAxis().setLabel(SIZE_UNIT_LABEL);
        ObservableList<BarChart.Series> barChartSeries = FXCollections.observableArrayList(
                new BarChart.Series(count + " largest", barChartData));
        topTen.setData(barChartSeries);
    }

    private void setCommands() {
        boolean hasCurrent = currentRoot != null;
        boolean hasParent = hasCurrent && currentRoot.getParent() != null;

        mnuRefresh.setDisable(!hasCurrent);
        cmdRefresh.setDisable(!hasCurrent);
        
        mnuParent.setDisable(!hasParent);
        cmdParent.setDisable(!hasParent);
    }

    private static class NodeComparator implements java.util.Comparator {
        private boolean ascend;

        public NodeComparator(boolean ascending) {
            ascend = ascending;
        }

        @Override
        public int compare(Object o1, Object o2) {
            FileNode n1 = (FileNode) o1;
            FileNode n2 = (FileNode) o2;
            if (n1.getSize() < n2.getSize()) {
                return ascend ? - 1 : 1;
            } else if (n1.getSize() > n2.getSize()) {
                return ascend ? 1 : -1;
            } else {
                return 0;
            }
        }
    }

    private class WorkerStateEventHandler implements EventHandler<WorkerStateEvent> {
        @Override
        public void handle(WorkerStateEvent t) {
            EventType etype = t.getEventType();
            if (WorkerStateEvent.WORKER_STATE_RUNNING.equals(etype)) {
                ctx.getMainWindow().getScene().setCursor(Cursor.WAIT);
            } else if (WorkerStateEvent.WORKER_STATE_SUCCEEDED.equals(etype)) {
                TreeItem root = (TreeItem) t.getSource().getValue();
                root.setExpanded(true);
                dirTree.setRoot(root);
                dirTree.getSelectionModel().selectFirst();
                ctx.getMainWindow().getScene().setCursor(Cursor.DEFAULT);
            } else if (WorkerStateEvent.WORKER_STATE_FAILED.equals(etype)) {
                Throwable ex = t.getSource().getException();
                if (ex != null) {
                    Logger.getLogger(DiskUseFXController.class.getName()).log(Level.SEVERE, null, ex);
                }
                ctx.getMainWindow().getScene().setCursor(Cursor.DEFAULT);
            } else if (WorkerStateEvent.WORKER_STATE_CANCELLED.equals(etype)) {
                ctx.getMainWindow().getScene().setCursor(Cursor.DEFAULT);
            }
        }
    }
}
