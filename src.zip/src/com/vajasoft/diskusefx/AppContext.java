package com.vajasoft.diskusefx;

import javafx.stage.Stage;

/**
 *
 * @author z705692
 */
public class AppContext {
    private Stage mainWindow;

    public AppContext(Stage mainWindow) {
        this.mainWindow = mainWindow;
    }

    public Stage getMainWindow() {
        return mainWindow;
    }
}
