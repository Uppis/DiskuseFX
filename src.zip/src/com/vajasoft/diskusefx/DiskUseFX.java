package com.vajasoft.diskusefx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Pertti Uppala
 */
public class DiskUseFX extends Application {
    AppContext ctx;
    
    @Override
    public void start(Stage stage) throws Exception {
        ctx = new AppContext(stage);

        DiskUseFXController controller = (DiskUseFXController)setSceneContent("DiskUseFX.fxml", stage);
        controller.setAppContext(ctx);

        stage.show();
    }

    private Initializable setSceneContent(String fromFxml, Stage toStage) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(DiskUseFX.class.getResource(fromFxml));
        Parent root = (Parent) loader.load();
        Scene scene = new Scene(root, 800, 600);
        toStage.setScene(scene);

        return (Initializable) loader.getController();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application. main() serves only as fallback in case the
     * application can not be launched through deployment artifacts, e.g., in IDEs with limited FX support. NetBeans
     * ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}